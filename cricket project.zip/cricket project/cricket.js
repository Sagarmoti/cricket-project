function computerChoiceGenerator(){
    randomNumber=Math.random()*3;
    if(randomNumber>0 && randomNumber <= 1){
         computerChoice='bat';
    }
    else if(randomNumber >1 && randomNumber <=2){
         computerChoice='ball';
        
    }else {
         computerChoice='stump';
        
    }
}